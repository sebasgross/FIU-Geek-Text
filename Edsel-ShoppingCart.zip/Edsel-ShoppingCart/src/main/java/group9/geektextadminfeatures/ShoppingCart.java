package group9.geektextadminfeatures;

import group9.geektextadminfeatures.Entities.Book;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.util.ArrayList;

@Data
@Document(collection = "shoppingcart")
public class ShoppingCart {
    @Id
    private Integer id = 4518974;
    private String userName = "Jeff";
    private ArrayList<Book> cart = new ArrayList<Book>();

    public void addToCart(Book book){
            cart.add(book);
    }

    public void removeFromCart(Book book){
            cart.remove(book);
    }

    public void viewCart(){
        for(Book view:cart){
            System.out.println(view);
        }
    }



}