package group9.geektextadminfeatures;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface CartRepo extends MongoRepository<ShoppingCart, Integer> {

}
