package group9.geektextadminfeatures;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeekTextAdminFeaturesApplicationTests {

    @Test
    void contextLoads() {
    }

}
