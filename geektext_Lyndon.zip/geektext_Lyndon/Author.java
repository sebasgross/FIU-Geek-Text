package com.GeekText9.geektext;

import java.util.ArrayList;
import java.util.Scanner;

public class Author {

    private Boolean go;
    private Boolean cont;
    private String yesNo, name;
    private ArrayList<String> author = new ArrayList<String>();
    private Scanner read = new Scanner(System.in);


    public String addAuthors() {

        go = true;
        cont = true;

        //continue to the loop until the user inputs N to exit out the loop
        while (go) {
            System.out.println("input the author's name");
            name = read.nextLine();
            author.add(name);
            cont = true;

            //ask the user if there is another author to add to the database
            while (cont){
                System.out.println("Is there another author?(Y/N)");
                yesNo = read.nextLine();

                if(!(yesNo.equals("Y")||yesNo.equals("N"))){
                    System.out.println("not a valid input");
                    cont = true;

                }else{

                    if (yesNo.equals("Y")){
                        cont = false;
                    }
                    else if (yesNo.equals("N")){
                        cont =false;
                        go = false;
                    }

                }

            }

        }
        //convert the Arraylist to one long String without the [] at the ends
        String author1String = author.toString();
        author1String = author1String.substring(1,author1String.length()-1);
        return author1String;
    }

}
