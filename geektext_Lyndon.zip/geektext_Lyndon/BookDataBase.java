package com.GeekText9.geektext;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.sql.*;

//MySQL Database user=root password = sWaHixOci4ribr!MIspi

@RestController
@RequestMapping("/serch_by_isbn")
public class BookDataBase {

    static final String DB_URL = "jdbc:mysql://localhost:3306/geektextdb";
    String username = "root";
    String password = "sWaHixOci4ribr!MIspi";
    Connection connection;

    @GetMapping
    public void addBookDetails(BookDetails bookDets) {

        {
            try {
                connection = DriverManager.getConnection(DB_URL, username, password);

                String sql = "INSERT INTO bookdatabase (title,author,publisher,genre,yearPublished,description,isbn,booksSold,price) " +
                        "VALUES (?,?,?,?,?,?,?,?,?)";

                PreparedStatement statement = connection.prepareStatement(sql);
                //adds book title to the DB
                statement.setString(1, bookDets.getTitle());
                statement.setString(2, bookDets.getAuthor());
                statement.setString(3, bookDets.getPublisher());
                statement.setString(4, bookDets.getGenre());
                statement.setInt(5, bookDets.getYearPublished());
                statement.setString(6, bookDets.getBookDescription());
                statement.setString(7, bookDets.getIsbn());
                statement.setInt(8, bookDets.getNumberSold());
                statement.setDouble(9, bookDets.getPrice());

                int row = statement.executeUpdate();
                if (row > 0) {
                    System.out.println("A new book has been propagated to the geektextdb\n" +
                            "------------------------------------------------\n");
                }
                connection.close();

            } catch (SQLException e) {
                System.out.println("Connection failed please try again.");
                e.printStackTrace();

            }
        }
    }

    public void searchBookByISBN(String isbnSearch) {

        String isbnS = isbnSearch;

        try {
            connection = DriverManager.getConnection(DB_URL, username, password);

            String sql = "SELECT * FROM bookdatabase WHERE isbn";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);

            while (resultSet.next()) {
                String titlePrint = resultSet.getString(2);
                String authorPrint = resultSet.getString(3);
                String publisherPrint = resultSet.getString(4);
                String genrePrint = resultSet.getString(5);
                int yearPrint = resultSet.getInt(6);
                String descriptionPrint = resultSet.getString(7);
                String isbnPrint = resultSet.getString(8);
                int numberSoldPrint = resultSet.getInt(9);
                double pricePrint = resultSet.getDouble(10);

                if (isbnS.equals(isbnPrint)) {
                    System.out.println("TITLE: " + titlePrint);

                    System.out.println("AUTHOR: " + authorPrint);

                    System.out.println("ISBN: " + publisherPrint);

                    System.out.println("DESCRIPTION: " + genrePrint);

                    System.out.println("GENRE: " + yearPrint);

                    System.out.println("PUBLISHER: " + descriptionPrint);

                    System.out.println("PRICE: " + isbnPrint);

                    System.out.println("BOOKS SOLD: " + numberSoldPrint);

                    System.out.println("PUBLICATION YEAR: " + pricePrint);

                    System.out.println("------------------------------------------\n");
                }
            }


            connection.close();

        } catch (SQLException e) {
            System.out.println("Connection failed please try again.");
            e.printStackTrace();

        }

    }


    public void searchBookByAuthor(String authorSearch) {

        String authorS = authorSearch;

        try {
            connection = DriverManager.getConnection(DB_URL, username, password);

            String sql = "SELECT * FROM bookdatabase WHERE isbn";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);

            while (resultSet.next()) {
                String titlePrint = resultSet.getString(2);
                String authorPrint = resultSet.getString(3);
                String publisherPrint = resultSet.getString(4);
                String genrePrint = resultSet.getString(5);
                int yearPrint = resultSet.getInt(6);
                String descriptionPrint = resultSet.getString(7);
                String isbnPrint = resultSet.getString(8);
                int numberSoldPrint = resultSet.getInt(9);
                double pricePrint = resultSet.getDouble(10);

                if (authorS.equals(authorPrint)) {
                    System.out.println("TITLE: " + titlePrint);

                    System.out.println("AUTHOR: " + authorPrint);

                    System.out.println("ISBN: " + publisherPrint);

                    System.out.println("DESCRIPTION: " + genrePrint);

                    System.out.println("GENRE: " + yearPrint);

                    System.out.println("PUBLISHER: " + descriptionPrint);

                    System.out.println("PRICE: " + isbnPrint);

                    System.out.println("BOOKS SOLD: " + numberSoldPrint);

                    System.out.println("PUBLICATION YEAR: " + pricePrint);

                    System.out.println("------------------------------------------\n");
                }
            }


            connection.close();

        } catch (SQLException e) {
            System.out.println("Connection failed please try again.");
            e.printStackTrace();

        }
    }
}