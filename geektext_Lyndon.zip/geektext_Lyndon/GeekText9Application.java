
package com.GeekText9.geektext;
import java.util.Scanner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GeekText9Application {

	public static void main(String[] args) {
		
	    //runs the springframework
		SpringApplication.run(GeekText9Application.class, args);

        //temporary data holders for user inputs
		double tempDouble;
		int tempInt;

        //scanner object to read user inputs
		Scanner read = new Scanner(System.in);

        //objects from the various classes in this program
		BookDataBase bookDataBase = new BookDataBase();
		GenreType genreList = new GenreType();
		Author authorList = new Author();
        BookDataBase bookDataBase1 = new BookDataBase();
		BookDetails bd;

		//variables need for the Bookdetails object
		String title ,isbn ,bookDescription ,publisher;
		double price;
		int numberSold, yearPublished;
		String bookGenre;
		String bookAuthor;


        // set string to nothing to continue the while loop unless the user inputs 0
		String tempString = "nothing";

		while (!tempString.equals(0)){

            //basic menu for the website admin to select what they want to do with the Geektext database
			System.out.print("Want to add a new book? ENTER IN 1\n" +
					"Want search the book database by ISBN? ENTER IN 2\n" +
					"Want to serch by author name? ENTER IN 3\n"+
					"Exit program. ENTER IN 0\n");

            //store the user input for the menu
			tempString = read.nextLine();

             // this if statment will ask the user to input the book detail information
			if( "1".equals(tempString)){

				System.out.print("TITLE: ");
				title = read.nextLine();

                //goes to he Author class to complete this operation
				System.out.print("AUTHOR: ");
				bookAuthor = authorList.addAuthors();

				System.out.print("ISBN: ");
				isbn = read.nextLine();

				System.out.print("DESCRIPTION: ");
				bookDescription = read.nextLine();

                //goes to the GenreType class to complete this operation
				System.out.print("GENRE: ");
				bookGenre = genreList.setGenre();

				System.out.print("PUBLISHER: ");
				publisher = read.nextLine();

				System.out.print("PRICE: ");
				price = read.nextDouble();

				System.out.print("BOOKS SOLD: ");
				numberSold = read.nextInt();

				System.out.print("PUBLICATION YEAR: ");
				yearPublished = read.nextInt();

                //inputs the userdata to the BookDetails object
				bd = new BookDetails(title,isbn,bookDescription,bookAuthor,bookGenre,publisher,price,numberSold,yearPublished);

				//adds the BookDetails object to the Database
				bookDataBase1.addBookDetails(bd);

                // set the temporary string to jump out of the while loop
				tempString = "nothing";

			}
			else if (tempString.equals("2")){

				String searchISBN;
				System.out.println("ENTER in the ISBN to search for the book");
				searchISBN = read.nextLine();

                //calls the method to search all instances of the given ISBN
				bookDataBase1.searchBookByISBN(searchISBN);

                // set the temporary string to jump out of the while loop
				tempString = "nothing";
			}

			else if(tempString.equals("3")){
				String searchAuthor;
				System.out.println("ENTER in the author's name to search for the book");
				searchAuthor = read.nextLine();

                //calls the method to search all instances of the given authors name
				bookDataBase1.searchBookByAuthor(searchAuthor);
			}
			//closes the program
			else if (tempString.equals("0")) {
				System.exit(0);
			}
	}

	}
}
