package com.mongodb.starter.repositories;

import com.mongodb.starter.models.Wishlist;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface WishlistRepository {

    Wishlist save(Wishlist wishlist);

//    List<Wishlist> saveAll(List<Wishlist> wishlist);

    List<Wishlist> findAll();

    List<Wishlist> findAll(List<String> ids);

//    Wishlist findOne(String id);
//
//    long count();
//
//    long delete(String id);
//
//    long delete(List<String> ids);
//
//    long deleteAll();
//
//    Wishlist update(Wishlist wishlist);
//
//    long update(List<Wishlist> ishlist);
//
//    double getAverageAge();

}
