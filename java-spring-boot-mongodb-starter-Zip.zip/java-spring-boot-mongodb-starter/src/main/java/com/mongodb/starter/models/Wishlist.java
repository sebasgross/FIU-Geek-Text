package com.mongodb.starter.models;

import org.bson.types.ObjectId;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

@JsonInclude(Include.NON_NULL)
public class Wishlist {
	
	@JsonSerialize(using = ToStringSerializer.class)
	private ObjectId id;
	private String name;
	private Integer number;
	private Object[] bookList;
	
	public ObjectId getId() {
		return id;
	}
	
    public Wishlist setId(ObjectId id) {
        this.id = id;
        return this;
    }

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getNumber() {
		return number;
	}
	public void setNumber(Integer number) {
		this.number = number;
	}
	public Object[] getBookList() {
		return bookList;
	}
	public void setBookList(Object[] bookList) {
		this.bookList = bookList;
	}
	
	 @Override
	    public String toString() {
	        return "Wishlist{" + "id=" + id + ", name='" + name + '\'' + ", number='" + number + '\'' + ", bookList=" + bookList + '}';
	    }
	
}
